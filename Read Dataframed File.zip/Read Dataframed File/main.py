#with open("Comparison.csv") as data_file:
#    data = data_file.readlines()
#    print(data)

#import csv

#with open("Comparison.csv") as data_file:
#    data = csv.reader(data_file)
#    for row in data:
#        print(row)
    
import pandas
data = pandas.read_csv("Comparison.csv")
print(type(data['RNN'])) #Pandas Series - like list - 1 dimension
print(type(data)) #Pandas DataFrame - 2 dimension

data_dict = data.to_dict()
#print(data_dict)

temp_list = data["RNN"].to_list()
#print(temp_list)
#print(len(temp_list))

average = sum(data["RNN"]) / len(data["RNN"])
#print(average)
#print(data["RNN"].mean())
#print(data["RNN"].max())

#Get Data in Column
#print(data["FNN"])
#print(data.FNN)

#Get Data in Row
print(data[data.FNN > 0.9])
print(data[data.RNN == data.RNN.max()])

data_dictionary = {
    "students": ["Amy","Jack","Mark"],
    "scores": [76,56,98]
}
data = pandas.DataFrame(data_dictionary)
print(data)
data.to_csv("new_data.csv")
