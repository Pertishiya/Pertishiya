from flask import Flask, render_template, request, jsonify
from hangman_art import stages, logo
from wordlist import word_list
import random

app = Flask(__name__)

# Initialize game variables
chosen_word = random.choice(word_list)
word_length = len(chosen_word)
display = ['_' for _ in range(word_length)]
lives = 6
end_of_game = False

def process_guess(guess):
    global lives
    global display
    global end_of_game

    message = ""
    stage_image = stages[lives]

    if guess in display:
        message = f"You've already guessed {guess}"
    elif guess not in chosen_word:
        message = f"You guessed {guess}, that's not in the word. You lose a life."
        lives -= 1
        if lives == 0:
            message = "You lose."
            end_of_game = True
    else:
        for position, letter in enumerate(chosen_word):
            if letter == guess:
                display[position] = letter

        if "_" not in display:
            message = "You win."
            end_of_game = True

    return message, stage_image

@app.route('/')
def home():
    return render_template('hangman.html', logo=logo, display=' '.join(display), lives=lives, chosen_word=chosen_word, stages=stages)

@app.route('/guess', methods=['POST'])
def guess():
    global lives
    global display
    global end_of_game

    if not end_of_game:
        guess = request.form['guess']
        message, stage_image = process_guess(guess)

        # Prepare JSON response with updated game state
        response_data = {
            'lives': lives,
            'message': message,
            'chosen_word': chosen_word,
            'display': ' '.join(display),
            'stage_image': stage_image,
            'end_of_game': end_of_game
        }
    else:
        # Game is already over
        response_data = {
            'message': "The game is already over."
        }

    return jsonify(response_data)

if __name__ == '__main__':
    app.run(debug=True)
